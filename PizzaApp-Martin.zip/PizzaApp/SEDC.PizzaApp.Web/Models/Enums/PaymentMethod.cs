﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SEDC.PizzaApp.Web.Models.Enums
{
    public enum PaymentMethod
    {
        Cash = 1,
        Card
    }
}
