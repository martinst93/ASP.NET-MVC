﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SEDC.PizzaApp.Web.Models.Enums
{
    public enum PizzaSize
    {
        Normal = 1,
        Family
    }
}
